import fetch from 'node-fetch';

/**
 * AGENTES LOCALES VÍA OLLAMA
 * Reemplaza fake data con conexiones reales a modelos locales
 */

export interface LocalAgent {
  id: string;
  name: string;
  model: string;
  status: 'ready' | 'downloading' | 'error';
  endpoint: string;
}

const OLLAMA_HOST = process.env.OLLAMA_HOST || 'http://localhost:11434';

/**
 * Mapeo de modelos Ollama → Agentes del servidor
 */
export const localAgentsConfig: LocalAgent[] = [
  {
    id: 'agent-1-local',
    name: 'Deepseek Coder',
    model: 'deepseek-coder',
    status: 'ready',
    endpoint: `${OLLAMA_HOST}/api/generate`,
  },
  {
    id: 'agent-2-local',
    name: 'Mistral',
    model: 'mistral',
    status: 'ready',
    endpoint: `${OLLAMA_HOST}/api/generate`,
  },
  {
    id: 'agent-3-local',
    name: 'Llama 3.2',
    model: 'llama3.2',
    status: 'ready',
    endpoint: `${OLLAMA_HOST}/api/generate`,
  },
  {
    id: 'agent-4-local',
    name: 'Gemma 4',
    model: 'gemma4',
    status: 'ready',
    endpoint: `${OLLAMA_HOST}/api/generate`,
  },
  {
    id: 'agent-5-local',
    name: 'Gemma 3',
    model: 'gemma3',
    status: 'ready',
    endpoint: `${OLLAMA_HOST}/api/generate`,
  },
];

/**
 * Verifica si Ollama está activo
 */
export async function checkOllamaHealth(): Promise<boolean> {
  try {
    const response = await fetch(`${OLLAMA_HOST}/api/tags`);
    return response.ok;
  } catch (err) {
    console.error('❌ Ollama no está activo en', OLLAMA_HOST);
    return false;
  }
}

/**
 * Obtiene lista de modelos disponibles en Ollama
 */
export async function getAvailableModels(): Promise<string[]> {
  try {
    const response = await fetch(`${OLLAMA_HOST}/api/tags`);
    if (!response.ok) return [];
    
    const data = await response.json() as any;
    return data.models?.map((m: any) => m.model) || [];
  } catch (err) {
    console.error('Error fetching models:', err);
    return [];
  }
}

/**
 * Envía prompt a un modelo Ollama
 * @param model - Nombre del modelo (ej: 'deepseek-coder')
 * @param prompt - Prompt del usuario
 * @param stream - Si true, devuelve respuesta en chunks
 */
export async function queryOllamaModel(
  model: string,
  prompt: string,
  stream = false
): Promise<string | AsyncIterable<string>> {
  try {
    const response = await fetch(`${OLLAMA_HOST}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model,
        prompt,
        stream,
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.statusText}`);
    }

    if (stream) {
      // Devuelve stream de respuesta
      return (async function* () {
        const reader = response.body as any;
        for await (const chunk of reader) {
          try {
            const line = chunk.toString();
            if (line.trim()) {
              const parsed = JSON.parse(line);
              if (parsed.response) {
                yield parsed.response;
              }
            }
          } catch (e) {
            // Ignorar líneas malformadas
          }
        }
      })();
    } else {
      // Acumula respuesta completa
      let fullResponse = '';
      const reader = response.body as any;
      for await (const chunk of reader) {
        try {
          const line = chunk.toString();
          if (line.trim()) {
            const parsed = JSON.parse(line);
            if (parsed.response) {
              fullResponse += parsed.response;
            }
          }
        } catch (e) {
          // Ignorar líneas malformadas
        }
      }
      return fullResponse;
    }
  } catch (err) {
    console.error(`Error querying ${model}:`, err);
    throw err;
  }
}

/**
 * Ejecuta deliberación multi-agente (todos los 5 agentes opinan)
 */
export async function deliberateMultiAgent(topic: string): Promise<any> {
  const opinions: Record<string, string> = {};

  for (const agent of localAgentsConfig) {
    try {
      console.log(`\n🤖 Consultando ${agent.name}...`);
      const opinion = await queryOllamaModel(
        agent.model,
        `Tema: "${topic}"\n\nDa tu opinión directa y breve (max 100 palabras). Sin rodeos.`,
        false
      ) as string;
      opinions[agent.id] = opinion.substring(0, 500);
    } catch (err) {
      console.error(`Error en ${agent.name}:`, err);
      opinions[agent.id] = `(Error: modelo no disponible)`;
    }
  }

  return {
    topic,
    timestamp: new Date().toISOString(),
    deliberation: opinions,
    activeAgents: localAgentsConfig.length,
  };
}

/**
 * Sintesis final después de deliberación
 */
export async function synthesizeOpinions(
  topic: string,
  opinions: Record<string, string>
): Promise<string> {
  const synthesizerModel = 'mistral'; // Usa Mistral como sintetizador

  const prompt = `
Tema: "${topic}"

Opiniones de 5 agentes:
${Object.entries(opinions)
  .map(([id, op]) => `- Agent ${id}: ${op}`)
  .join('\n')}

Sintetiza en 1-2 párrafos: ¿cuál es el consenso? ¿Qué acción se recomienda?
Sé directo, sin rodeos.
`;

  try {
    const synthesis = await queryOllamaModel(synthesizerModel, prompt, false) as string;
    return synthesis.substring(0, 1000);
  } catch (err) {
    console.error('Error en síntesis:', err);
    return '(Error al sintetizar)';
  }
}

export default {
  checkOllamaHealth,
  getAvailableModels,
  queryOllamaModel,
  deliberateMultiAgent,
  synthesizeOpinions,
  localAgentsConfig,
};
