import { randomUUID } from "node:crypto";

import type { AgentCard } from "@a2a-js/sdk";
import {
  AgentEvent,
  AgentExecutor,
  DefaultRequestHandler,
  ExecutionEventBus,
  InMemoryTaskStore,
  RequestContext,
} from "@a2a-js/sdk/server";

export const agent1Card: AgentCard = {
  name: "MasterCode Agent 1",
  description: "Agente A2A de pensamiento analítico.",
  protocolVersion: "1.0",
  version: "0.1.0",
  url: "http://localhost:3000/a2a/agent1",
  capabilities: {
    streaming: false,
    pushNotifications: false,
  },
  defaultInputModes: ["text"],
  defaultOutputModes: ["text"],
  skills: [
    {
      id: "analytical-thinking",
      name: "Pensamiento analítico",
      description: "Analiza problemas y requerimientos.",
      tags: ["analysis", "reasoning"],
      examples: ["Analiza este problema."],
    },
  ],
};

class Agent1Executor implements AgentExecutor {
  async execute(
    context: RequestContext,
    eventBus: ExecutionEventBus,
  ): Promise<void> {
    const message = {
      kind: "message" as const,
      messageId: randomUUID(),
      role: "agent" as const,
      parts: [
        {
          kind: "text" as const,
          text: `Agent 1 recibió: ${context.userMessage.parts
            .map((part) => ("text" in part ? part.text : ""))
            .join("")}`,
        },
      ],
      contextId: context.contextId,
    };

    eventBus.publish(AgentEvent.message(message));
    eventBus.finished();
  }

  async cancelTask(): Promise<void> {}
}

export const agent1RequestHandler = new DefaultRequestHandler(
  agent1Card,
  new InMemoryTaskStore(),
  new Agent1Executor(),
);
