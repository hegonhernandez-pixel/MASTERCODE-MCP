# 🚀 Instrucciones para Correr MVP - MasterCode MCP

## Estado Actual
✅ Archivos reparados:
- `server.ts` — A2A handlers configurados
- `src/a2a/agent1.ts` — Agente A2A listo
- `package.json` — Todas las librerías presentes

---

## Paso 1: Instalar Dependencias

En tu PowerShell (Windows), dentro de `C:\proyects\mastercode-mcp`:

```powershell
npm install
```

**Tiempo estimado:** 2-3 minutos (primera vez)

**Qué pasa:**
- Descarga 196 paquetes
- Genera `node_modules/`
- Valida compatibilidad de versiones

---

## Paso 2: Crear Archivo `.env`

En la raíz del proyecto (`C:\proyects\mastercode-mcp\.env`):

```env
# Gemini API (opcional para MVP - si está vacío, usa fallback determinista)
GEMINI_API_KEY=

# Server Express
PORT=3000
NODE_ENV=development

# GitHub Token (para pasos posteriores)
GITHUB_TOKEN=
```

**Nota:** 
- `GEMINI_API_KEY` vacío = funciona (fallback a lógica determinista)
- `PORT=3000` puede cambiar si otro proceso usa ese puerto

---

## Paso 3: Correr el Servidor

```powershell
npm run dev
```

**Salida esperada:**
```
[MasterCode MCP] Multi-Model Server running on http://0.0.0.0:3000
```

---

## Endpoints Disponibles Después de `npm run dev`

### Health Check
```
GET http://localhost:3000/api/health
```
Respuesta esperada:
```json
{
  "status": "ok",
  "hasGeminiKey": false,
  "model": "gemini-3.8-flash",
  "assignedModels": {
    "agent1": "Claude Code (Anthropic Claude 3.7 / Opus)",
    "agent2": "GPT-4o (OpenAI)",
    "agent3": "Gemini 2.5 Pro (Google)",
    "agent4": "Gemini 3.8 Flash / Pro (Google)"
  }
}
```

### Agent Card (A2A Protocol)
```
GET http://localhost:3000/.well-known/agent-card.json
```

### Agent 1 JSON-RPC
```
POST http://localhost:3000/a2a/agent1
Content-Type: application/json

{
  "jsonrpc": "2.0",
  "id": 1,
  "method": "sendMessage",
  "params": {
    "message": {
      "kind": "message",
      "role": "user",
      "parts": [{"kind": "text", "text": "Analiza este problema"}]
    }
  }
}
```

---

## Validación Rápida (Curl / Postman)

Después de `npm run dev`, abre otra terminal PowerShell:

```powershell
# Test 1: Health check
curl http://localhost:3000/api/health

# Test 2: Agent 1 card
curl http://localhost:3000/.well-known/agent-card.json
```

---

## Problemas Comunes

| Problema | Causa | Solución |
|---|---|---|
| `ERR! 404 Not Found` en npm install | npm cache corrupto | `npm cache clean --force` → `npm install` |
| `Port 3000 already in use` | Otro proceso en 3000 | Cambiar `PORT=3001` en `.env` |
| `Cannot find module '@a2a-js/sdk'` | node_modules faltante | `npm install` de nuevo |
| `GEMINI_API_KEY not found` | `.env` no creado | Crear `.env` con variables vacías |
| `TypeError: Cannot read properties` | A2A handlers mal montados | ✅ Ya está reparado (líneas 1588-1590) |

---

## Próximos Pasos Después del MVP

1. **Conectar repositorio GitHub** → usar `POST /api/github-push`
2. **Entrenar agentes** → llamar `POST /api/orchestrate` con topic
3. **Desplegar a Docker** → usar `docker-compose.multi-chip.yml`
4. **Compilar a APK** → usar `build_apk.sh`

---

## Archivo de Configuración

**Ubicación:** `.env` (raíz del proyecto)

Ejemplo completo si tienes GEMINI_API_KEY:

```env
GEMINI_API_KEY=AIzaSyDtQxxxxxxxxxxxxxxxx
PORT=3000
NODE_ENV=development
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxx
```

Sin GEMINI_API_KEY funciona igual → usa lógica determinista.

---

¿Problemas después de ejecutar `npm run dev`? Reporta el error exacto.
